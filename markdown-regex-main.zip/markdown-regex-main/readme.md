### REGEXP_HEADER

---

### REGEXP_IMAGE

---

### REGEXP_LINK

---

### REGEXP_STRONG

---

### REGEXP_DEL

---

### REGEXP_Q

---

### REGEXP_CODE

---

### REGEXP_BLOCKQUOTE

---

### REGEXP_HR

---

### REGEXP_PARAGRAPH

---

### REGEXP_BR

---

### REGEXP_EMPTY_BLOCKQUOTE

---

### REGEXP_EM

---

  
###  REGEXP_UL_LIST

---

###  REGEXP_OL_LIST

---

###  REGEXP_EMPTY_UL

---

###  REGEXP_EMPTY_OL

---


submodule for https://github.com/atherdon/markdown-to-email

npm link: https://www.npmjs.com/package/markdown-regex

Hackernoon article: https://hackernoon.com/open-sourcing-regular-expressions-for-markdown-syntax-module

@todo: 
- we need to move some tests here


for tests can be used:
 https://gist.github.com/sequielo/3521937
 https://github.com/mxstbr/markdown-test-file/blob/master/TEST.md
 
 
 
 
#### Arthur Tkachenko articles

* [https://hackernoon.com/5-reasons-why-newsletters-should-be-part-of-your-business-strategy](https://hackernoon.com/5-reasons-why-newsletters-should-be-part-of-your-business-strategy)
* [https://hackernoon.com/organizing-an-advanced-structure-for-html-email-template](https://hackernoon.com/organizing-an-advanced-structure-for-html-email-template)
* [https://hackernoon.com/how-i-started-to-build-react-components-for-email-templates](https://hackernoon.com/how-i-started-to-build-react-components-for-email-templates)
* [https://hackernoon.com/introducing-a-simple-npm-module-with-email-templates](https://hackernoon.com/introducing-a-simple-npm-module-with-email-templates)
* [https://hackernoon.com/glossary-for-non-technies](https://hackernoon.com/glossary-for-non-technies)
* [https://hackernoon.com/email-marketing-and-how-to-curate-an-effective-business-newsletter](https://hackernoon.com/email-marketing-and-how-to-curate-an-effective-business-newsletter)
* [https://hackernoon.com/exploring-substack-for-building-your-newsletter](https://hackernoon.com/exploring-substack-for-building-your-newsletter)
* [https://hackernoon.com/building-a-design-system-for-email-templates-react](https://hackernoon.com/building-a-design-system-for-email-templates-react)
* [https://hackernoon.com/together4victory-list-of-email-marketing-tools](https://hackernoon.com/together4victory-list-of-email-marketing-tools)
* [https://hackernoon.com/cool-newsletters-for-developers-part-1](https://hackernoon.com/cool-newsletters-for-developers-part-1)
* [https://hackernoon.com/cool-resources-for-sending-emails](https://hackernoon.com/cool-resources-for-sending-emails)
